package movable;
public interface Movable {
	public void move();
}
